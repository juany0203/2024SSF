//package com.tapie.eclair_card.fragment.taro
//
//import androidx.compose.foundation.Image
//import androidx.compose.foundation.clickable
//import androidx.compose.foundation.layout.*
//import androidx.compose.foundation.lazy.LazyColumn
//import androidx.compose.foundation.lazy.LazyRow
//import androidx.compose.material3.IconButton
//import androidx.compose.material3.Text
//import androidx.compose.runtime.*
//import androidx.compose.ui.Alignment
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.graphics.TransformOrigin
//import androidx.compose.ui.graphics.graphicsLayer
//import androidx.compose.ui.res.painterResource
//import androidx.compose.ui.text.style.TextAlign
//import androidx.compose.ui.tooling.preview.Devices
//import androidx.compose.ui.tooling.preview.Preview
//import androidx.compose.ui.unit.dp
//import androidx.compose.ui.unit.sp
//import androidx.lifecycle.viewmodel.compose.viewModel
//import androidx.navigation.NavController
//import androidx.navigation.compose.rememberNavController
//import com.tapie.eclair_card.R
//import com.tapie.eclair_card.components.atomic.ButtonProps
//import com.tapie.eclair_card.components.atomic.CardBack
//import com.tapie.eclair_card.components.atomic.CenteredTextButton
//import com.tapie.eclair_card.components.atomic.LogoIcon
//import com.tapie.eclair_card.components.atomic.TextButton
//import com.tapie.eclair_card.components.atomic.typography.TaroTypography
//import com.tapie.eclair_card.data.SharedViewModel
//import com.tapie.eclair_card.navigation.Screen
//import com.tapie.eclair_card.ui.theme.LightPurpleColor
//import kotlin.random.Random
//
//@Composable
//fun TaroScreen(navController: NavController, sharedViewModel: SharedViewModel = viewModel()) {
//    // 상태 변수: 선택된 카드 번호들 (최대 3개까지 선택 가능)
//    var selectedCards by remember { mutableStateOf(listOf<Int>()) }
//    // 컴포저블이 시작될 때 타로 선택을 초기화
//    LaunchedEffect(Unit) {
//        sharedViewModel.resetTarotSelection()
//    }
//
//    LazyColumn(
//        modifier = Modifier
//            .fillMaxSize(), // 너비, 높이를 최대로 설정
//        horizontalAlignment = Alignment.CenterHorizontally // 가로 중앙 정렬
//    ) {
//        item {
//            // 헤더 섹션
//            Box(
//                modifier = Modifier
//                    .fillMaxWidth() // 너비를 최대로 설정
//                    .padding(vertical = 8.dp) // 위아래 여백 설정
//            ) {
//                Row(
//                    verticalAlignment = Alignment.CenterVertically, // 세로 중앙 정렬
//                    horizontalArrangement = Arrangement.Start, // 가로 시작 부분 정렬
//                    modifier = Modifier.align(Alignment./* 빈 칸 */)// 중앙 시작 부분
//                ) { // 뒤로 가기 버튼
//                    IconButton(onClick = {
//                        navController.navigate(Screen.Home.route) {
//                            popUpTo(navController.graph.startDestinationId) {
//                                saveState = true // 이전 상태를 저장
//                            }
//                            launchSingleTop = true // 단일 인스턴스만 실행
//                            restoreState = true // 이전 상태를 복원
//                        }
//                    }) { // 뒤로 가기 아이콘 이미지 설정
//                        Image(
//                            painter = painterResource(id = R.drawable.arrow_back_ios),
//                            contentDescription = "Back", // 이미지 설명
//                            modifier = Modifier.size(24.dp) // 이미지 크기 설정
//                        )
//                    }
//                }
//                // 타로 화면의 제목 텍스트
//                Text(
//                    text = "타로",
//                    fontSize = 18.sp, // 텍스트 크기 설정
//                    modifier = Modifier.align(Alignment.Center)// 가로 중앙 정렬
//                )
//
//                Box(
//                    modifier = Modifier.align(Alignment.CenterEnd) //끝부분 정렬
//                ) { // 로고 아이콘 설정
//                    LogoIcon(modifier = Modifier./* 빈 칸 */) // 크기를 24.dp 로 설정
//                }
//            }
//        }
//
//        item {
//            // 원형 카드 레이아웃과 드래그 안내 텍스트
//            Box(
//                modifier = Modifier
//                    .fillMaxWidth(), // 가로 전체를 채움
//                contentAlignment = Alignment.TopCenter // 상단 중앙에 내용 정렬
//            ) {
//                Column(
//                    horizontalAlignment = Alignment.CenterHorizontally,  // 가로 중앙
//                ) {
//                    Image(
//                        painter = painterResource(id = R.drawable.drag),
//                        contentDescription = "Drag Indicator", // 이미지 설명
//                        modifier = Modifier
//                            .padding(top = 10.dp) // 위쪽 여백 10.dp 설정
//                            .width(155.dp) // 이미지 너비 설정
//                            .height(23.dp) // 이미지 높이 설정
//                    )
//
//                    Text(
//                        text = "드래그 해주세요.",
//                        style = TaroTypography.TaroExplain, // 텍스트 스타일 설정
//                        color = LightPurpleColor, // 텍스트 색상 설정
//                        textAlign = TextAlign.Center // 텍스트를 중앙 정렬
//                    )
//
//
//                    Spacer(modifier = Modifier.height(20.dp)) // 위쪽 여백 설정
//
//                    LazyRow(
//                        modifier = Modifier.padding(top = 20.dp), // 위쪽 여백 설정
//                        horizontalArrangement = Arrangement.spacedBy(16.dp), // 간격 설정
//                        contentPadding = PaddingValues(horizontal = 32.dp) // 가로 여백 설정
//                    ) {
//                        items(22) { index ->
//                            CardBack(
//                                modifier = Modifier
//                                    .size(150.dp, 225.dp)  // 카드 크기 설정
//                                    .graphicsLayer(
//                                        rotationZ = 0f, // 카드의 회전 각도 설정
//                                        transformOrigin = TransformOrigin(0.5f, 0.5f)
//                                    )
//                                    ./* 빈 칸 */ { // 클릭 시 동작 수행
//                                        // 카드 클릭 시 랜덤한 숫자 선택
//                                        val randomNumber = Random.nextInt(0, 22)
//                                        if (selectedCards.size < 3 && randomNumber !in selectedCards) {
//                                            sharedViewModel.addSelectedCard(randomNumber)
//                                            selectedCards = sharedViewModel.selectedCards.value ?: listOf()
//                                        }
//                                    }
//                            )
//                        }
//                    }
//
//                    Spacer(modifier = Modifier.height(20.dp)) // 여백 추가
//
//                    /* 빈 칸 */ { // selectedCards.size 가 3보다 적으면
//                        // 카드가 3장 선택되지 않았을 때 안내 텍스트
//                        Text(
//                            text = "카드를 세 장 골라주세요!",
//                            style = TaroTypography.TaroExplain, // 텍스트 스타일 설정
//                            color = LightPurpleColor, // 텍스트 색상 설정
//                            modifier = Modifier.align(Alignment.CenterHorizontally), // 중앙에 배치
//                            textAlign = TextAlign.Center // 텍스트를 중앙 정렬
//                        )
//                    }
//                }
//            }
//        }
//
//        item {
//            // 카드 선택 후 표시하는 섹션
//            Column(
//                modifier = Modifier
//                    .fillMaxWidth() // 가로 전체를 채움
//                    .padding(top = 16.dp), // 위쪽 여백 설정
//                horizontalAlignment = Alignment.CenterHorizontally // 가로 중앙 정렬
//            ) {
//                Row(
//                    horizontalArrangement = Arrangement.Center // 가로 중앙 정렬
//                ) {
//                    // 선택된 카드들을 화면에 표시
//                    selectedCards.forEach { cardNumber ->
//                        DisplayCard(cardNumber, Modifier.size(101.dp, 165.dp))
//                        // 선택된 카드를 표시하는 컴포저블
//                    }
//                }
//
//                // 결과 보기 버튼을 표시
//                if (selectedCards.size == 3) {
//                    Spacer(modifier = Modifier.height(20.dp))
//                    // 버튼과 카드 사이의 공간 추가
//                    TextButton(
//                        props = ButtonProps(text = "결과 보기", // 버튼 텍스트
//                            buttonWidth = 345, // 버튼 너비 설정
//                             buttonHeight = 53), // 버튼 높이 설정
//                        onClick = { navController.navigate(Screen.Past.route) } // 버튼 클릭 시 과거 화면으로 이동
//                    )
//                }
//            }
//        }
//    }
//}
//
//@Preview(showBackground = true, device = Devices.PIXEL_4)
//@Composable
//fun TaroScreenPreview() {
//    // 가짜 NavController와 SharedViewModel을 생성합니다.
//    val navController = rememberNavController()
//    val sharedViewModel = SharedViewModel().apply {
//        // 필요한 경우 초기 상태를 설정할 수 있습니다.
//        setSelectedCards(listOf(1, 2)) // 가짜 데이터 설정
//    }
//
//    TaroScreen(navController = navController, sharedViewModel = sharedViewModel)
//}
//
